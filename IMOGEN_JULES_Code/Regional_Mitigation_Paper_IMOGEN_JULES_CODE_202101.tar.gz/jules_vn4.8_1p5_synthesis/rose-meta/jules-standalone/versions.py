import rose.upgrade
import re

from .version34_40 import *
from .version40_41 import *
from .version41_42 import *
from .version42_43 import *
from .version43_44 import *
from .version44_45 import *
from .version45_46 import *
from .version46_47 import *
from .version47_48 import *

class vn48_t468(rose.upgrade.MacroUpgrade):

    """Upgrade macro from JULES by Sarah Chadburn"""

    BEFORE_TAG = "vn4.8"
    AFTER_TAG = "vn4.8_t468"

    def upgrade(self, config, meta_config=None):
        """Upgrade a JULES runtime app configuration."""

        # Add settings
	self.add_setting(config, ["namelist:jules_soil_biogeochem", "l_ch4_interactive"], ".false.")
	self.add_setting(config, ["namelist:jules_soil_biogeochem", "ch4_substrate"], "1")
        return config, self.reports
