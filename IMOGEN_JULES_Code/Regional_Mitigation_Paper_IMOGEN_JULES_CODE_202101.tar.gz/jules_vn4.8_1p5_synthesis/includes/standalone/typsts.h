! Dummy include file for STASH variables that aren't required standalone
