! C_HT_M constants for subroutine SF_EXCH

      ! height of 10m level for diagnostic calculations (m).
      REAL,PARAMETER:: Z10M  = 10.0

      ! height of 1.5m level for diagnostic calculations (m).
      REAL,PARAMETER:: Z1P5M = 1.5

! C_HT_M end
