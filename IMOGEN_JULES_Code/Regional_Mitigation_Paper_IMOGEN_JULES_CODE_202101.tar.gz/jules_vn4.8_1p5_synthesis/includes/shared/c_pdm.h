! C_PDM start
! 5.5 17/02/03    Required for large-scale hydrology L_PDM code.
!
! Soil layer thickness for PDM (m):
      REAL,PARAMETER :: DZ_PDM = 1.0
! Shape factor for PDM:
       REAL,PARAMETER :: B_PDM = 1.0
!
! C_PDM end
