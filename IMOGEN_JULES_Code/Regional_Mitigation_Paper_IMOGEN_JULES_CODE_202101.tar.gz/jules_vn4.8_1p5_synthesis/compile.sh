#!/bin/bash
module load intel/15.0

export JULES_COMPILER=intel
export JULES_BUILD=normal
export JULES_NETCDF=netcdf
export JULES_NETCDF_PATH=/group_workspaces/jasmin/jules/jules_build/libs
export JULES_NETCDF_INC_PATH=$JULES_NETCDF_PATH/include
export JULES_NETCDF_LIB_PATH=$JULES_NETCDF_PATH/lib
#export JULES_PLATFORM=jasmin-lotus-intel
export JULES_MPI=mpi
#export JULES_FFLAGS_EXTRA="-I/group_workspaces/jasmin/jules/jules_build/libs/include -lm -lz -xHost -O3 -no-prec-div -static-intel -ip "
export JULES_FFLAGS_EXTRA="-xHost -static-intel -zero -init=arrays -init=zero -CB"

#  -O3 -xHost -ip -no-prec-div -static-intel -init=zero -init=arrays -zero"

#export JULES_LDFLAGS_EXTRA="-L/group_workspaces/jasmin/jules/jules_build/libs/lib -lnetcdff -lnetcdf -lhdf5_hl -lhdf5 -lz -lm"
export JULES_LDFLAGS_EXTRA="-lnetcdff -lnetcdf -lhdf5_hl -lhdf5 -lz"

if [[ $1 == "new" ]]; then
fcm make --new -f etc/fcm-make/make.cfg
else
fcm make -f etc/fcm-make/make.cfg
fi
